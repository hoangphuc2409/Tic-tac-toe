﻿namespace ProjectServer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            startButton = new CustomButton.VBButton();
            txtIP = new Label();
            SuspendLayout();
            // 
            // startButton
            // 
            startButton.BackColor = Color.MediumSlateBlue;
            startButton.BackgroundColor = Color.MediumSlateBlue;
            startButton.BorderColor = Color.PaleVioletRed;
            startButton.BorderRadius = 20;
            startButton.BorderSize = 0;
            startButton.FlatAppearance.BorderSize = 0;
            startButton.FlatStyle = FlatStyle.Flat;
            startButton.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            startButton.ForeColor = Color.White;
            startButton.Location = new Point(492, 41);
            startButton.Name = "startButton";
            startButton.Size = new Size(179, 50);
            startButton.TabIndex = 0;
            startButton.Text = "START";
            startButton.TextColor = Color.White;
            startButton.UseVisualStyleBackColor = false;
            startButton.Click += startButton_Click;
            // 
            // txtIP
            // 
            txtIP.AutoSize = true;
            txtIP.Font = new Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point);
            txtIP.Location = new Point(50, 56);
            txtIP.Name = "txtIP";
            txtIP.Size = new Size(85, 34);
            txtIP.TabIndex = 1;
            txtIP.Text = "label1";
            txtIP.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(708, 435);
            Controls.Add(txtIP);
            Controls.Add(startButton);
            DoubleBuffered = true;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SERVER";
            FormClosed += Form1_FormClosed;
            Shown += Form1_Shown;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CustomButton.VBButton startButton;
        private Label txtIP;
    }
}