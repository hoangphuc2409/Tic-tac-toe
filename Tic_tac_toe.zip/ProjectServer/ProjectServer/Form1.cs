﻿using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;

namespace ProjectServer
{
    public partial class Form1 : Form
    {
        bool isFirst = true;
        Socket server;
        IPEndPoint IP;
        List<Socket> ClientList;
        public Form1()
        {
            InitializeComponent();
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        }
        private void Form1_Shown(object sender, EventArgs e)
        {
            txtIP.Text = ShowIPAdress();
        }
        private void startButton_Click(object sender, EventArgs e)
        {
            CreateS();
        }

        // TẠO SERVER
        public void CreateS()
        {
            string ip = txtIP.Text;
            ClientList = new List<Socket>();
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IP = new IPEndPoint(IPAddress.Parse(ip), 8000);
            server.Bind(IP);
            // Tạo luồng chấp nhận client
            Thread listen = new Thread(() =>
            {
                try
                {
                    while (true)
                    {
                        server.Listen(30);
                        Socket client = server.Accept();
                        ClientList.Add(client);
                        if (isFirst)
                        {
                            string a = "First";
                            client.Send(SData(a));
                            isFirst = false;
                        }
                        else
                        {
                            string b = "notFirst";
                            client.Send(SData(b));
                        }
                        Thread receive = new Thread(RECEIVE);
                        receive.IsBackground = true;
                        receive.Start(client);
                    }
                }
                catch
                {
                    IP = new IPEndPoint(IPAddress.Parse(ip), 8000);
                    server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                }
            });
            listen.IsBackground = true;
            listen.Start();
        }
        void RECEIVE(Object obj)
        {
            Socket client = obj as Socket;
            try
            {
                while (client.Connected == true)
                {
                    byte[] data = new byte[1024];
                    client.Receive(data);
                    byte[] DATA = data;
                    foreach (Socket item in ClientList)
                    {
                        try
                        {
                            if (item != null && item != client)
                            {
                                item.Send(DATA);
                            }
                        }
                        catch { }
                    }
                }
            }
            catch
            {
                ClientList.Remove(client);
                client.Close();
            }
        }
        public string ShowIPAdress()
        {
            string ipv4 = "";
            NetworkInterface[] networkInterfaces = NetworkInterface.GetAllNetworkInterfaces();//Lấy danh sách card mạng
            foreach (NetworkInterface NF in networkInterfaces)
            {   //kiểm tra card mạng wifi hoặc ethernet và đang hoạt động
                if ((NF.NetworkInterfaceType == NetworkInterfaceType.Wireless80211 ||
                     NF.NetworkInterfaceType == NetworkInterfaceType.Ethernet) && NF.OperationalStatus == OperationalStatus.Up)
                {
                    IPInterfaceProperties ipProperties = NF.GetIPProperties();//card mạng hợp lệ thì duyệt địa chỉ IP
                    foreach (UnicastIPAddressInformation IP in ipProperties.UnicastAddresses)
                    {   //Kiểm tra AddressFamily của IP có phải là địa chỉ IPv4 không
                        if (IP.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            ipv4 = IP.Address.ToString();
                            break;
                        }
                    }
                }
            }
            return ipv4;
        }
        public byte[] SData(Object obj) //Hàm chuyển object sang byte
        {
            MemoryStream MS = new MemoryStream();
            BinaryFormatter BF = new BinaryFormatter();
            BF.Serialize(MS, obj); //Lưu trữ obj đã được serialize vào MS
            return MS.ToArray();
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            server.Close();
        }

    }
}