﻿namespace Project
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            CBoard = new Panel();
            Avatar = new PictureBox();
            panel1 = new Panel();
            panel2 = new Panel();
            PlayerName = new TextBox();
            txtSend = new TextBox();
            btnSend = new Button();
            txtReceive = new RichTextBox();
            Symbol = new PictureBox();
            Cooldown = new ProgressBar();
            menuStrip1 = new MenuStrip();
            newGameToolStripMenuItem = new ToolStripMenuItem();
            undoToolStripMenuItem = new ToolStripMenuItem();
            CD = new System.Windows.Forms.Timer(components);
            contextMenuStrip1 = new ContextMenuStrip(components);
            ((System.ComponentModel.ISupportInitialize)Avatar).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Symbol).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // CBoard
            // 
            CBoard.BackColor = Color.FromArgb(50, 50, 50);
            CBoard.ForeColor = Color.Black;
            CBoard.Location = new Point(12, 27);
            CBoard.Name = "CBoard";
            CBoard.Size = new Size(546, 582);
            CBoard.TabIndex = 0;
            // 
            // Avatar
            // 
            Avatar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            Avatar.BackColor = SystemColors.ActiveCaption;
            Avatar.ErrorImage = null;
            Avatar.Image = (Image)resources.GetObject("Avatar.Image");
            Avatar.Location = new Point(0, 0);
            Avatar.Name = "Avatar";
            Avatar.Size = new Size(353, 278);
            Avatar.SizeMode = PictureBoxSizeMode.StretchImage;
            Avatar.TabIndex = 1;
            Avatar.TabStop = false;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            panel1.Controls.Add(Avatar);
            panel1.Location = new Point(558, 27);
            panel1.Name = "panel1";
            panel1.Size = new Size(353, 261);
            panel1.TabIndex = 2;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            panel2.BackColor = Color.OldLace;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(PlayerName);
            panel2.Controls.Add(txtSend);
            panel2.Controls.Add(btnSend);
            panel2.Controls.Add(txtReceive);
            panel2.Controls.Add(Symbol);
            panel2.Controls.Add(Cooldown);
            panel2.Location = new Point(557, 285);
            panel2.Name = "panel2";
            panel2.Size = new Size(353, 324);
            panel2.TabIndex = 3;
            // 
            // PlayerName
            // 
            PlayerName.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            PlayerName.Location = new Point(15, 26);
            PlayerName.Name = "PlayerName";
            PlayerName.Size = new Size(169, 30);
            PlayerName.TabIndex = 7;
            PlayerName.TextAlign = HorizontalAlignment.Center;
            // 
            // txtSend
            // 
            txtSend.BackColor = Color.FromArgb(255, 255, 192);
            txtSend.BorderStyle = BorderStyle.FixedSingle;
            txtSend.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtSend.Location = new Point(15, 271);
            txtSend.Multiline = true;
            txtSend.Name = "txtSend";
            txtSend.Size = new Size(205, 34);
            txtSend.TabIndex = 6;
            // 
            // btnSend
            // 
            btnSend.BackColor = Color.MediumSlateBlue;
            btnSend.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btnSend.ForeColor = Color.White;
            btnSend.Location = new Point(238, 256);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(107, 55);
            btnSend.TabIndex = 5;
            btnSend.Text = "Send";
            btnSend.UseVisualStyleBackColor = false;
            btnSend.Click += btnSend_Click;
            // 
            // txtReceive
            // 
            txtReceive.BackColor = Color.FromArgb(255, 255, 192);
            txtReceive.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtReceive.Location = new Point(15, 138);
            txtReceive.Name = "txtReceive";
            txtReceive.Size = new Size(299, 112);
            txtReceive.TabIndex = 3;
            txtReceive.Text = "";
            // 
            // Symbol
            // 
            Symbol.BorderStyle = BorderStyle.FixedSingle;
            Symbol.Location = new Point(207, 8);
            Symbol.Name = "Symbol";
            Symbol.Size = new Size(145, 109);
            Symbol.SizeMode = PictureBoxSizeMode.StretchImage;
            Symbol.TabIndex = 2;
            Symbol.TabStop = false;
            // 
            // Cooldown
            // 
            Cooldown.BackColor = Color.YellowGreen;
            Cooldown.Location = new Point(15, 76);
            Cooldown.Maximum = 20000;
            Cooldown.Name = "Cooldown";
            Cooldown.Size = new Size(169, 30);
            Cooldown.Step = 200;
            Cooldown.TabIndex = 1;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { newGameToolStripMenuItem, undoToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(923, 30);
            menuStrip1.TabIndex = 4;
            menuStrip1.Text = "menuStrip1";
            // 
            // newGameToolStripMenuItem
            // 
            newGameToolStripMenuItem.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            newGameToolStripMenuItem.ForeColor = Color.Green;
            newGameToolStripMenuItem.Name = "newGameToolStripMenuItem";
            newGameToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.N;
            newGameToolStripMenuItem.Size = new Size(113, 26);
            newGameToolStripMenuItem.Text = "New Game";
            newGameToolStripMenuItem.Click += newGameToolStripMenuItem_Click;
            // 
            // undoToolStripMenuItem
            // 
            undoToolStripMenuItem.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            undoToolStripMenuItem.ForeColor = Color.Firebrick;
            undoToolStripMenuItem.Name = "undoToolStripMenuItem";
            undoToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.U;
            undoToolStripMenuItem.Size = new Size(66, 26);
            undoToolStripMenuItem.Text = "Undo";
            undoToolStripMenuItem.Click += undoToolStripMenuItem_Click;
            // 
            // CD
            // 
            CD.Tick += CD_Tick;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(20, 20);
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(923, 626);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(CBoard);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "TIC TAC TOE";
            FormClosed += Form1_FormClosed;
            ((System.ComponentModel.ISupportInitialize)Avatar).EndInit();
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)Symbol).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel CBoard;
        private PictureBox Avatar;
        private Panel panel1;
        private Panel panel2;
        private PictureBox Symbol;
        private ProgressBar Cooldown;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem newGameToolStripMenuItem;
        private ToolStripMenuItem undoToolStripMenuItem;
        private System.Windows.Forms.Timer CD;
        private ContextMenuStrip contextMenuStrip1;
        private RichTextBox txtReceive;
        private Button btnSend;
        private TextBox txtSend;
        private TextBox PlayerName;
    }
}