﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        private void Form3_Shown(object sender, EventArgs e)
        {
            txtIP.Text = ShowIPAdress();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtIP.Text != string.Empty && txtName.Text != string.Empty)
            {
                this.Hide();
                string name = txtName.Text;
                string ip = txtIP.Text;
                Form1 form1 = new Form1(name, ip);
                form1.ShowDialog();
            }
            else
            {
                MessageBox.Show("Hãy nhập đầy đủ tên người chơi và địa chỉ IP của server muốn kết nối");
            }
        }
        public string ShowIPAdress()
        {
            string ipv4 = "";
            NetworkInterface[] networkInterfaces = NetworkInterface.GetAllNetworkInterfaces();//Lấy danh sách card mạng
            foreach (NetworkInterface NF in networkInterfaces)
            {   //kiểm tra card mạng wifi hoặc ethernet và đang hoạt động
                if ((NF.NetworkInterfaceType == NetworkInterfaceType.Wireless80211 ||
                     NF.NetworkInterfaceType == NetworkInterfaceType.Ethernet) && NF.OperationalStatus == OperationalStatus.Up)
                {
                    IPInterfaceProperties ipProperties = NF.GetIPProperties();//card mạng hợp lệ thì duyệt địa chỉ IP
                    foreach (UnicastIPAddressInformation IP in ipProperties.UnicastAddresses)
                    {   //Kiểm tra AddressFamily của IP có phải là địa chỉ IPv4 không
                        if (IP.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            ipv4 = IP.Address.ToString();
                            break;
                        }
                    }
                }
            }
            return ipv4;
        }

        
    }
}
