﻿using CustomButton;
using Project;
using System.Data;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Net.WebSockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Data.SqlClient;
using static Project.Transport;

namespace Project
{
    public partial class Form1 : Form
    {
        public string LoginName;
        Manager Game;
        Socket client;
        SqlConnection conn = null;
        public Form1(string name, string ip)
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
            string IP = ip;
            LoginName = name;
            Game = new Manager(CBoard, Symbol, PlayerName);
            Game.End += NewGame_End;
            Game.Click += NewGame_Click;
            NewGame();
            ConnectS(IP);
            string Name = LoginName.ToUpper();
            PlayerName.Text = Name;
            //
            byte[] ReceiveData = new byte[1024];
            client.Receive(ReceiveData);
            string data = (string)DData(ReceiveData);
            FIRST(data);
            WAIT();
        }

        //Hàm gửi vị trí đánh tới đối thủ
        private void NewGame_Click(object? sender, BEvent e)
        {
            undoToolStripMenuItem.Enabled = true;
            CD.Start();
            Cooldown.Value = 0;
            //Gửi thông tin ô cờ đã đánh tới người chơi đối thủ
            Transport data = new Transport(2, e.Click, "");
            SEND(data);
            //
            if (Symbol.Image == Image.FromFile(Application.StartupPath + "\\Resources\\p2.png")) PlayerName.ForeColor = Color.CornflowerBlue;
            else if (Symbol.Image == Image.FromFile(Application.StartupPath + "\\Resources\\p1.png")) PlayerName.ForeColor = Color.IndianRed;
            PlayerName.Text = " Opponent's Turn";
            undoToolStripMenuItem.Enabled = false;
            CBoard.Enabled = false;
            WAIT();
        }

        // Tắt thanh cooldown khi kết thúc game
        private void NewGame_End(object? sender, EventArgs e)
        {
            CD.Stop();
            CBoard.Enabled = false;
            undoToolStripMenuItem.Enabled = false;
        }

        // Kết thúc game khi hết thời gian cooldown
        private void CD_Tick(object sender, EventArgs e)
        {
            Cooldown.PerformStep();
            if (Cooldown.Value >= Cooldown.Maximum)
            {
                CD.Stop();
                if (CBoard.Enabled == true)
                {
                    MessageBox.Show("TIMEOUT! YOU LOSE!");
                }
                else if(CBoard.Enabled == false)
                {
                    MessageBox.Show("TIMEOUT! YOU WIN!");
                }
                CBoard.Enabled = false;
                undoToolStripMenuItem.Enabled = false;
            }
        }

        //CHỨC NĂNG NEWGAME
        void NewGame()
        {
            CD.Stop();
            Cooldown.Value = 0; // reset CoolDown về 0
            Game.CreateNewBoard();
        }
        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewGame();
            PlayerName.ForeColor = Color.IndianRed;
            PlayerName.Text = LoginName.ToUpper();
            Transport data = new Transport(0, new Point(), "");
            SEND(data);
            CBoard.Enabled = true;
        }

        //CHỨC NĂNG UNDO
        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UndoGame();
            Transport data = new Transport(1, new Point(), "");
            SEND(data);
        }
        void UndoGame()
        {
            Game.UNDO();
            Cooldown.Value = 0;
            undoToolStripMenuItem.Enabled = false;
        }


        // *** KẾT NỐI MẠNG LAN ***
        void SEND(Object data)
        {
            byte[] DATA = SData(data);
            client.Send(DATA);

        }
        void RECEIVE()
        {
            try
            {
                byte[] ReceiveData = new byte[1024];
                client.Receive(ReceiveData);
                Transport Data = (Transport)DData(ReceiveData);
                switch (Data.Com)
                {
                    case 0: //NewGame
                        this.Invoke((MethodInvoker)(() =>
                        {
                            NewGame();
                            CBoard.Enabled = false;
                            Symbol.Image = Image.FromFile(Application.StartupPath + "\\Resources\\p2.png");
                            string Name = LoginName.ToUpper();
                            PlayerName.Text = Name;
                            PlayerName.ForeColor = Color.CornflowerBlue;
                        }));
                        break;
                    case 1: // UNDO
                        UndoGame();
                        Cooldown.Value = 0;
                        break;
                    case 2: // RECEIVED CHESS COORDINATE
                        this.Invoke((MethodInvoker)(() =>
                        {
                            string Name = LoginName.ToUpper();
                            PlayerName.Text = Name;
                            if (Symbol.Image == Image.FromFile(Application.StartupPath + "\\Resources\\p1.png")) PlayerName.ForeColor = Color.IndianRed;
                            else if (Symbol.Image == Image.FromFile(Application.StartupPath + "\\Resources\\p2.png")) PlayerName.ForeColor = Color.CornflowerBlue;
                            //
                            Cooldown.Value = 0;
                            CD.Start();
                            CBoard.Enabled = true;
                            Game.OpponentChess(Data.Point);
                            undoToolStripMenuItem.Enabled = true;
                        }));
                        break;
                    case 3:// RECEIVED MESSAGE
                        this.Invoke((MethodInvoker)(() =>
                        {
                            txtReceive.Text += Data.Mess;
                        }));
                        break;
                    default: break;
                }
                WAIT();
            }
            catch { }
        }
        void WAIT()
        {
            Thread Wait = new Thread(RECEIVE);
            Wait.IsBackground = true;
            Wait.Start();
        }
        void FIRST(string data)
        {
            if (data == "First")
            {
                PlayerName.ForeColor = Color.IndianRed;
                Symbol.Image = Image.FromFile(Application.StartupPath + "\\Resources\\p1.png");
                MessageBox.Show("YOU WILL ACT FIRST!","Your turn", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CBoard.Enabled = true;

            }
            else
            {
                PlayerName.ForeColor = Color.CornflowerBlue;
                Symbol.Image = Image.FromFile(Application.StartupPath + "\\Resources\\p2.png");
                MessageBox.Show("YOU WILL ACT SECOND!","Opponent's turn", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CBoard.Enabled = false;
            }
        }

        // HÀM KẾT NỐI TỚI SERVER
        public void ConnectS(string ip)
        {
            client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(ip), 8000);
            try
            {
                client.Connect(endPoint);
            }
            catch (Exception ex)
            {
                MessageBox.Show("CANNOT CONNECT TO SERVER! " + ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        //Hàm chuyển object sang byte
        public byte[] SData(Object obj)
        {
            MemoryStream MS = new MemoryStream();
            BinaryFormatter BF = new BinaryFormatter();
            BF.Serialize(MS, obj); //Lưu trữ obj đã được serialize vào MS
            return MS.ToArray();
        }

        //Hàm chuyển byte về object
        public object DData(byte[] Array)
        {
            MemoryStream MS = new MemoryStream(Array);
            BinaryFormatter BF = new BinaryFormatter();
            MS.Position = 0;
            return BF.Deserialize(MS);
        }
        private void btnSend_Click(object sender, EventArgs e)
        {
            string Message = LoginName + ": " + txtSend.Text + "\n";
            Transport data = new Transport(3, new Point(), Message);
            SEND(data);
            txtReceive.Text += Message;
            txtSend.Text = "";
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Close();
        }
    }
}
