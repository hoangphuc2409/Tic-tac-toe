﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    [Serializable]
    public class Transport //DỮ LIỆU ĐƯỢC GỬI
    {
        private int com; // các lệnh của game
        public int Com
        {
            get { return com; }
            set { com = value; }
        }
        //
        private Point point;
        public Point Point
        {
            get { return point; }
            set { point = value; }
        }
        //
        private string mess;
        public string Mess
        {
            get { return mess; }
            set { mess = value; }
        }
        public Transport(int com, Point point, string mess)
        {
            this.com = com;
            this.point = point;
            this.mess = mess;
        }
    }
}