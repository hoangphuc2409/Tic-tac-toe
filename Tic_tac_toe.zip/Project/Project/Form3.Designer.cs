﻿namespace Project
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            txtName = new TextBox();
            txtIP = new TextBox();
            btnLogin = new CustomButton.VBButton();
            SuspendLayout();
            // 
            // txtName
            // 
            txtName.Font = new Font("Times New Roman", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            txtName.Location = new Point(266, 148);
            txtName.Name = "txtName";
            txtName.Size = new Size(328, 40);
            txtName.TabIndex = 0;
            // 
            // txtIP
            // 
            txtIP.Font = new Font("Times New Roman", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            txtIP.Location = new Point(266, 240);
            txtIP.Name = "txtIP";
            txtIP.Size = new Size(328, 40);
            txtIP.TabIndex = 1;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.MediumSlateBlue;
            btnLogin.BackgroundColor = Color.MediumSlateBlue;
            btnLogin.BorderColor = Color.PaleVioletRed;
            btnLogin.BorderRadius = 20;
            btnLogin.BorderSize = 0;
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btnLogin.ForeColor = Color.White;
            btnLogin.Location = new Point(266, 318);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(178, 50);
            btnLogin.TabIndex = 2;
            btnLogin.Text = "LOG IN";
            btnLogin.TextColor = Color.White;
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(687, 392);
            Controls.Add(btnLogin);
            Controls.Add(txtIP);
            Controls.Add(txtName);
            DoubleBuffered = true;
            Name = "Form3";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login Form";
            Shown += Form3_Shown;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtName;
        private TextBox txtIP;
        private CustomButton.VBButton btnLogin;
    }
}