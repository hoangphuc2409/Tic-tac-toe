﻿using CustomButton;
using Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    [Serializable]
    public class Manager
    {
        //KHAI BÁO CÁC THUỘC TÍNH
        private Panel chessBoard;
        public Panel ChessBoard { get => chessBoard; set => chessBoard = value; }
        //
        private TextBox playerName;
        public TextBox PlayerName { get => playerName; set => playerName = value; }
        //
        private PictureBox symbol;
        public PictureBox Symbol { get => symbol; set => symbol = value; }      
        //
        private int current; // Người chơi hiện tại
        public int Current { get => current; set => current = value; }
        //
        private List<List<VBButton>> matrix;
        public List<List<VBButton>> Matrix { get => matrix; set => matrix = value; }
        //
        private List<Player> player;
        internal List<Player> Player { get => player; set => player = value; }
        //
        private event EventHandler<BEvent> click;
        public event EventHandler<BEvent> Click
        {
            add => click += value;
            remove => click -= value;
        }
        //
        private event EventHandler end;
        public event EventHandler End
        {
            add => end += value;
            remove => end -= value;
        }

        //Stack lưu lại các nước đi của người chơi
        private Stack<Point> playerStack;
        public Stack<Point> PlayerStack 
        { 
            get => playerStack;
            set => playerStack = value; 
        }


        //KHỞI TẠO
        public Manager(Panel chessBoard, PictureBox symbol, TextBox playerName)
        {
            this.PlayerName = playerName;
            this.Symbol = symbol;
            this.ChessBoard = chessBoard;
            this.player = new List<Player>()
            {
                new Player(Image.FromFile(Application.StartupPath +"\\Resources\\p1.png")),
                new Player(Image.FromFile(Application.StartupPath +"\\Resources\\p2.png")),
                new Player(Image.FromFile(Application.StartupPath +"\\Resources\\pHeart.png"))

            };
        }

        //CÁC PHƯƠNG THỨC
        private Point ChessPoint(VBButton b) //LẤY TỌA ĐỘ Ô CỜ
        {
            int Y = Convert.ToInt32(b.Tag);
            int X = Matrix[Y].IndexOf(b);
            Point ToaDo = new Point(X, Y);
            return ToaDo;
        }
        // KHỞI TẠO BÀN CỜ
        public void CreateNewBoard()
        {
            ChessBoard.Controls.Clear();
            ChessBoard.Enabled = false;
            PlayerStack = new Stack<Point>();
            current = 0;
            Symbol.Image = Player[current].Symbol;
            Matrix = new List<List<VBButton>>();
            VBButton preB = new VBButton() { Width = 0, Location = new Point(0, 0) }; // Khởi tạo ô cờ đầu tiên
            for (int i = 0; i < 17; i++) // Tạo ma trận bàn cờ
            {
                Matrix.Add(new List<VBButton>());
                for (int j = 0; j < 17; j++)
                {
                    VBButton b = new VBButton()
                    {
                        Width = 34,
                        Height = 34,
                        BorderRadius = 0,
                        BorderColor = Color.PaleVioletRed,
                        BorderSize = 1,
                        BackColor = Color.FromArgb(32, 32, 32),
                        BackgroundImageLayout = ImageLayout.Stretch,
                        Tag = i.ToString(),//Lưu vị trí cột
                        Location = new Point(preB.Location.X + preB.Width, preB.Location.Y) //Ô cờ tiếp theo sẽ nằm cạnh ô đầu tiên trên cùng 1 hàng
                    };
                    b.Click += B_Click;
                    ChessBoard.Controls.Add(b);
                    Matrix[i].Add(b);
                    preB = b; // Ô tiếp theo giờ sẽ là oldB, vòng lặp tiếp tục
                }  //  Tạo hàng tiếp theo bằng cách khởi tạo lại vị trí và giá trị của ô đầu tiên
                preB.Location = new Point(0, preB.Location.Y + 34);
                preB.Width = 0; preB.Height = 0;
            }

        }
        // CHỌN Ô CỜ
        private void B_Click(object sender, EventArgs e)
        {
            VBButton b = sender as VBButton; // Nút được click vào là nút được chọn
            if (b.BackgroundImage != null)
            {
                return;
            }
            b.BackgroundImage = Player[current].Symbol;
            PlayerStack.Push(ChessPoint(b)); // Đưa tọa độ ô vừa đánh vào stack
            if (current == 0) current = 1;
            else current = 0;
            Symbol.Image = Player[current].Symbol;
            if (click != null)
            {
                click(this, new BEvent(ChessPoint(b)));
            }

            // KẾT THÚC TRÒ CHƠI TẠI Ô CỜ ĐƯỢC CHỌN
            if (Doc(b) || Ngang(b) || CheoC(b) || CheoP(b))
            {
                EndGame();
                playerName.Text = "YOU WIN!";
                if(playerName.ForeColor == Color.IndianRed)
                {
                    Symbol.Image = Image.FromFile(Application.StartupPath + "\\Resources\\p1.png");
                }
                else if(playerName.ForeColor == Color.CornflowerBlue)
                {
                    Symbol.Image = Image.FromFile(Application.StartupPath + "\\Resources\\p2.png");
                }
                MessageBox.Show("YOU WIN!");
            }
        }
        public void OpponentChess(Point point) //Hàm lấy thông tin ô cờ đối thủ đã đánh
        {
            VBButton b = Matrix[point.Y][point.X];
            if (b.BackgroundImage != null)
            {
                return;
            }
            b.BackgroundImage = Player[current].Symbol;
            PlayerStack.Push(ChessPoint(b));
            if (current == 0) current = 1;
            else current = 0;
            Symbol.Image = Player[current].Symbol;
            if (Doc(b) || Ngang(b) || CheoC(b) || CheoP(b))
            {
                EndGame();
                playerName.Text = "YOU LOSE!";
                MessageBox.Show("YOU LOSE!");
            }
        }

        // ĐIỀU KIỆN THẮNG
        private bool Ngang(VBButton b)  //THẮNG HÀNG NGANG
        {
            Point point = ChessPoint(b);
            int Left = 0;
            for (int i = point.X; i >= 0; i--)// đếm bên trái
            {
                if (Matrix[point.Y][i].BackgroundImage == b.BackgroundImage)
                {
                    Left++;
                }
                else
                    break;
            }
            int Right = 0;
            for (int i = point.X + 1; i < 17; i++)//đếm bên phải
            {
                if (Matrix[point.Y][i].BackgroundImage == b.BackgroundImage)
                {
                    Right++;
                }
                else
                    break;
            }
            // đánh dấu vị trí thắng
            if (Left + Right == 5) 
            {
                int a = 0, c = 0;
                int x = point.X, y = point.X + 1;
                while (a < Left)
                {
                    Matrix[point.Y][x].BackgroundImage = player[2].Symbol;
                    x--;
                    a++;
                }
                while (c < Right)
                {
                    Matrix[point.Y][y].BackgroundImage = player[2].Symbol;
                    y++;
                    c++;
                }
            }
            return Left + Right == 5;
        }

        private bool Doc(VBButton b) //THẮNG HÀNG DỌC
        {
            Point point = ChessPoint(b);
            int Top = 0;
            for (int i = point.Y; i >= 0; i--)
            {
                if (Matrix[i][point.X].BackgroundImage == b.BackgroundImage)
                {
                    Top++;
                }
                else
                    break;
            }

            int Bottom = 0;
            for (int i = point.Y + 1; i < 17; i++)
            {
                if (Matrix[i][point.X].BackgroundImage == b.BackgroundImage)
                {
                    Bottom++;
                }
                else
                    break;
            }
            // đánh dấu vị trí thắng
            if (Top + Bottom == 5)
            {
                int a = 0, c = 0;
                int x = point.Y, y = point.Y + 1;
                while (a < Top)
                {
                    Matrix[x][point.X].BackgroundImage = player[2].Symbol;
                    x--;
                    a++;
                }
                while (c < Bottom)
                {
                    Matrix[y][point.X].BackgroundImage = player[2].Symbol;
                    y++;
                    c++;
                }

            }
            return Top + Bottom == 5;
        }
        private bool CheoC(VBButton b) //THẮNG ĐƯỜNG CHÉO CHÍNH
        {
            Point point = ChessPoint(b);
            int Top = 0;
            for (int i = 0; i <= point.X; i++)
            {
                if (point.Y - i < 0 || point.X - i < 0)
                    break;
                if (Matrix[point.Y - i][point.X - i].BackgroundImage == b.BackgroundImage)
                {
                    Top++;
                }
                else
                    break;
            }

            int Bottom = 0;
            for (int i = 1; i <= 17 - point.X; i++)
            {
                if (point.Y + i >= 17 || point.X + i >= 17)
                    break;
                if (Matrix[point.Y + i][point.X + i].BackgroundImage == b.BackgroundImage)
                {
                    Bottom++;
                }
                else
                    break;
            }
            // đánh dấu vị trí thắng
            if (Top + Bottom == 5) 
            {
                int a = 0, c = 0;
                int x = 0, y = 1;
                while (a < Top)
                {
                    Matrix[point.Y - x][point.X - x].BackgroundImage = player[2].Symbol;
                    x++;
                    a++;
                }
                while (c < Bottom)
                {
                    Matrix[point.Y + y][point.X + y].BackgroundImage = player[2].Symbol;
                    y++;
                    c++;
                }

            }
            return Top + Bottom == 5;
        }
        private bool CheoP(VBButton b) //THẮNG ĐƯỜNG CHÉO PHỤ
        {
            Point point = ChessPoint(b);
            int Top = 0;
            for (int i = 0; i <= point.X; i++)
            {
                if (point.X + i > 17 || point.Y - i < 0)
                    break;
                if (Matrix[point.Y - i][point.X + i].BackgroundImage == b.BackgroundImage)
                {
                    Top++;
                }
                else
                    break;
            }

            int Bottom = 0;
            for (int i = 1; i <= 17 - point.X; i++)
            {
                if (point.Y + i >= 17 || point.X - i < 0)
                    break;
                if (Matrix[point.Y + i][point.X - i].BackgroundImage == b.BackgroundImage)
                {
                    Bottom++;
                }
                else
                    break;
            }
            // đánh dấu vị trí thắng
            if (Top + Bottom == 5) 
            {
                int a = 0, c = 0;
                int x = 0, y = 1;
                while (a < Top)
                {
                    Matrix[point.Y - x][point.X + x].BackgroundImage = player[2].Symbol;
                    x++;
                    a++;
                }
                while (c < Bottom)
                {
                    Matrix[point.Y + y][point.X - y].BackgroundImage = player[2].Symbol;
                    y++;
                    c++;
                }

            }
            return Top + Bottom == 5;
        }
        // KẾT THÚC GAME
        public void EndGame()
        {
            if (end != null)
                end(this, new EventArgs());
        }
        // CHỨC NĂNG UNDO
        public bool UNDO()
        {
            if (PlayerStack.Count == 0)
            {
                return false;
            }
            bool U1 = Undo();
            bool U2 = Undo();
            Point UndoChess = PlayerStack.Peek();
            if (current == 0) current = 0;
            else current = 1;
            return U1 && U2;
        }
        private bool Undo()
        {
            if (PlayerStack.Count == 0)
            {
                return false; //Không thể undo khi chưa đánh ô cờ nào
            }
            Point UndoChess = PlayerStack.Pop();
            VBButton b = Matrix[UndoChess.Y][UndoChess.X]; // Lấy tọa độ của ô cờ vừa đánh
            b.BackgroundImage = null;
            Symbol.Image = Player[current].Symbol;
            return true;
        }
    }
    public class BEvent : EventArgs
    {
        private Point click;
        public Point Click
        {
            get { return click; }
            set { click = value; }
        }
        public BEvent(Point point)
        {
            this.Click = point;
        }
    }
}