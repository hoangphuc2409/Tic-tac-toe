﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    [Serializable]
    internal class Player
    { 
        private Image symbol; // Biểu tượng ô cờ của người chơi
        public Image Symbol { get => symbol; set => symbol = value; }
        //
        public Player( Image symbol)
        { 
            this.Symbol = symbol;
        }
    }
}