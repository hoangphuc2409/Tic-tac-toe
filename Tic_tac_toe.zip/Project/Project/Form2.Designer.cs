﻿namespace Project
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            Play = new CustomButton.VBButton();
            vbButton2 = new CustomButton.VBButton();
            SuspendLayout();
            // 
            // Play
            // 
            Play.BackColor = Color.MediumSlateBlue;
            Play.BackgroundColor = Color.MediumSlateBlue;
            Play.BorderColor = Color.PaleVioletRed;
            Play.BorderRadius = 20;
            Play.BorderSize = 0;
            Play.FlatAppearance.BorderSize = 0;
            Play.FlatStyle = FlatStyle.Flat;
            Play.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            Play.ForeColor = Color.White;
            Play.Location = new Point(66, 381);
            Play.Name = "Play";
            Play.Size = new Size(181, 50);
            Play.TabIndex = 0;
            Play.Text = "PLAY";
            Play.TextColor = Color.White;
            Play.UseVisualStyleBackColor = false;
            Play.Click += Play_Click;
            // 
            // vbButton2
            // 
            vbButton2.BackColor = Color.IndianRed;
            vbButton2.BackgroundColor = Color.IndianRed;
            vbButton2.BorderColor = Color.PaleVioletRed;
            vbButton2.BorderRadius = 20;
            vbButton2.BorderSize = 0;
            vbButton2.FlatAppearance.BorderSize = 0;
            vbButton2.FlatStyle = FlatStyle.Flat;
            vbButton2.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            vbButton2.ForeColor = Color.White;
            vbButton2.Location = new Point(343, 381);
            vbButton2.Name = "vbButton2";
            vbButton2.Size = new Size(188, 50);
            vbButton2.TabIndex = 2;
            vbButton2.Text = "QUIT";
            vbButton2.TextColor = Color.White;
            vbButton2.UseVisualStyleBackColor = false;
            vbButton2.Click += vbButton2_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(639, 455);
            Controls.Add(vbButton2);
            Controls.Add(Play);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MENU";
            Load += Form2_Load;
            ResumeLayout(false);
        }

        #endregion

        private CustomButton.VBButton Play;
        private CustomButton.VBButton vbButton2;
    }
}